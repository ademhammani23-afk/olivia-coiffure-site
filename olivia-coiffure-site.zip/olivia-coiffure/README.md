# Olivia Coiffure — site vitrine

Site statique responsive en HTML, CSS et JavaScript. Aucune installation ou compilation n'est nécessaire.

## Aperçu en local
1. Décompressez le dossier.
2. Ouvrez `index.html` dans un navigateur.
3. Une connexion Internet est nécessaire pour charger les polices Google Fonts et les photographies Unsplash.

## À personnaliser avant publication
- **Adresse exacte / carte :** dans `index.html`, recherchez « Adresse exacte à renseigner ». La carte décorative ne prétend pas représenter l'emplacement exact. Le lien ouvre une recherche générale de coiffeurs à Cavaillon.
- **E-mail :** dans `script.js`, remplacez `bonjour@exemple.fr` par l'adresse e-mail réelle. Remplacez également le texte visible correspondant dans `index.html`. Le formulaire utilise ensuite le logiciel e-mail du visiteur (mailto), il ne transmet pas directement les messages depuis un serveur.
- **Services et tarifs :** les prestations affichées sont une proposition de démonstration. Confirmez les services, prix, horaires et coordonnées avec le salon.
- **Avis :** aucun faux avis n'est présent. Ajoutez uniquement des avis authentiques avec l'autorisation des personnes concernées.
- **Photos :** les photos sont chargées depuis Unsplash via des URL distantes. Pour une publication professionnelle, vérifiez les conditions de licence et remplacez-les idéalement par des photos du salon et de ses réalisations, avec les autorisations nécessaires.
- **Mentions légales et confidentialité :** ajoutez les informations légales de l'exploitant et une politique de confidentialité adaptée avant la mise en ligne. Si vous ajoutez des outils de mesure ou des cookies non essentiels, configurez le consentement requis.

## Publication gratuite avec GitHub Pages
1. Créez ou connectez-vous à un compte GitHub.
2. Créez un dépôt public, par exemple `olivia-coiffure`.
3. Téléversez `index.html`, `styles.css`, `script.js` et `README.md` à la racine du dépôt.
4. Dans le dépôt, ouvrez **Settings → Pages**.
5. Dans **Build and deployment**, choisissez **Deploy from a branch**, puis `main` et `/ (root)`, et enregistrez.
6. Après quelques minutes, GitHub affiche l'adresse publique du site dans la section Pages.

Autres options statiques : Netlify ou Cloudflare Pages. Les offres et conditions peuvent changer ; vérifiez-les au moment de publier.

## Structure
- `index.html` — contenu et sections du site
- `styles.css` — design responsive, couleurs et animations
- `script.js` — menu mobile, animations au défilement et formulaire de contact
- `README.md` — instructions
